#!/usr/bin/env python3
"""Visit Moganshan identity asset set.
Mark: Direction 01 "Grove" — seven uneven bamboo culms, staggered nodes, no leaves.
Palette: A "Bamboo & Mist".  Wordmark: Playfair Display, outlined to paths."""
import os, glob
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.misc.transform import Transform

OUT = "/home/claude/moganshan/assets"
FS  = "/home/claude/fonts/node_modules/@fontsource"
os.makedirs(OUT, exist_ok=True)

# ---------- Palette A ----------
BAMBOO = "#1F4A3C"
LEAF   = "#3C6B4A"
MIST   = "#E8EDE9"
STONE  = "#D8CFC0"
AMBER  = "#E0A458"
INK    = "#1A1D1B"

# ---------- geometry ----------
BASE, NODE_H = 86.0, 3.0

def rrect(x, y, w, h, r):
    r = min(r, w/2, h/2)
    return (f"M{x+r:.2f} {y:.2f}H{x+w-r:.2f}A{r:.2f} {r:.2f} 0 0 1 {x+w:.2f} {y+r:.2f}"
            f"V{y+h-r:.2f}A{r:.2f} {r:.2f} 0 0 1 {x+w-r:.2f} {y+h:.2f}"
            f"H{x+r:.2f}A{r:.2f} {r:.2f} 0 0 1 {x:.2f} {y+h-r:.2f}"
            f"V{y+r:.2f}A{r:.2f} {r:.2f} 0 0 1 {x+r:.2f} {y:.2f}Z")

def rect(x, y, w, h):
    return f"M{x:.2f} {y:.2f}H{x+w:.2f}V{y+h:.2f}H{x:.2f}Z"

def rhythm(top, start=13.0, gaps=(15.0, 17.5, 19.0, 21.0)):
    """Internodes short near the crown, longer toward the base — how bamboo grows.
    The uneven spacing is what stops the culms reading as a bar chart."""
    ys, y = [], top + start
    for g in gaps:
        if y < BASE - 9:
            ys.append(round(y, 1))
        y += g
    return ys

# Seven culms: uneven widths, uneven heights, nodes that do not line up.
GROVE = [(8.0, 9.0, 62.0), (19.0, 11.0, 44.0), (32.0, 8.0, 30.0), (42.0, 12.0, 13.0),
         (56.0, 8.0, 27.0), (66.0, 11.0, 46.0), (79.0, 9.0, 60.0)]

# Reduced variant for small sizes: four heavy culms, one node each.
# At 16px the node all but disappears; it earns its keep on retina, where a
# "16px" favicon is actually rendered at 32.
GROVE_SMALL = [(6.0, 18.0, 52.0), (28.0, 20.0, 22.0), (52.0, 16.0, 38.0), (72.0, 18.0, 58.0)]
FAV_NODES   = {6.0: [67.0], 28.0: [45.0, 68.0], 52.0: [59.0], 72.0: [70.0]}

def mark_path(spec=GROVE, nodes=True):
    p = []
    for x, w, top in spec:
        p.append(rrect(x, top, w, BASE - top, w/2))
        if nodes:
            p += [rect(x, ny, w, NODE_H) for ny in rhythm(top)]
    return "".join(p)

def favicon_path():
    p = []
    for x, w, top in GROVE_SMALL:
        p.append(rrect(x, top, w, BASE - top, w/2))
        p += [rect(x, ny, w, 4.0) for ny in FAV_NODES[x]]
    return "".join(p)

def culm_paths(spec=GROVE):
    out = []
    for x, w, top in spec:
        d = rrect(x, top, w, BASE - top, w/2)
        d += "".join(rect(x, ny, w, NODE_H) for ny in rhythm(top))
        out.append(d)
    return out

MARK = mark_path()
FAV  = favicon_path()

def svg(w, h, body):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" '
            f'viewBox="0 0 {w} {h}">\n{body}\n</svg>\n')

def write(name, content):
    with open(os.path.join(OUT, name), "w") as f:
        f.write(content)
    print("  ", name)

def path_el(d, fill, indent="  "):
    return f'{indent}<path fill="{fill}" fill-rule="evenodd" d="{d}"/>'

# ---------- wordmark: Playfair Display, outlined ----------
def face(family, weight):
    g = glob.glob(f"{FS}/{family}/files/{family}-latin-{weight}-normal.woff2")
    if not g:
        g = sorted(glob.glob(f"{FS}/{family}/files/*latin-*-normal.woff2"))
    return g[0]

class Outliner:
    def __init__(self, path):
        f = TTFont(path)
        self.gs   = f.getGlyphSet()
        self.cmap = f.getBestCmap()
        self.upem = f["head"].unitsPerEm
        self.hmtx = f["hmtx"]

    def text_path(self, s, size, tracking=0.0):
        sc = size / self.upem
        d, x = [], 0.0
        for ch in s:
            gn = self.cmap.get(ord(ch))
            if gn is None:
                x += size * 0.4 + tracking
                continue
            pen = SVGPathPen(self.gs)
            self.gs[gn].draw(TransformPen(pen, Transform(sc, 0, 0, -sc, x, 0)))
            c = pen.getCommands()
            if c:
                d.append(c)
            x += self.hmtx[gn][0] * sc + tracking
        return "".join(d), x - tracking

pf_name = Outliner(face("playfair-display", 500))   # "Moganshan"
pf_caps = Outliner(face("playfair-display", 600))   # "VISIT"

# ---------- lockups ----------
def build_lockup(reversed_=False):
    mark_size, gap = 62.0, 22.0
    name_size, eyebrow_size = 40.0, 12.0
    eb_d, eb_w = pf_caps.text_path("VISIT", eyebrow_size, eyebrow_size * 0.34)
    nm_d, nm_w = pf_name.text_path("Moganshan", name_size, name_size * 0.01)

    W = mark_size + gap + max(eb_w, nm_w)
    H = mark_size
    block_h = eyebrow_size + 12 + name_size * 0.72
    top = (H - block_h) / 2
    eb_y = top + eyebrow_size
    nm_y = eb_y + 12 + name_size * 0.72
    tx = mark_size + gap

    mc = MIST  if reversed_ else BAMBOO
    ec = AMBER if reversed_ else LEAF
    nc = MIST  if reversed_ else BAMBOO

    body = (f'  <g transform="scale({mark_size/96:.5f})">\n'
            + path_el(MARK, mc, "    ") + '\n  </g>\n'
            f'  <g transform="translate({tx:.2f},{eb_y:.2f})"><path fill="{ec}" d="{eb_d}"/></g>\n'
            f'  <g transform="translate({tx:.2f},{nm_y:.2f})"><path fill="{nc}" d="{nm_d}"/></g>')
    return svg(round(W, 1), round(H, 1), body)

def build_stacked():
    mark_size, name_size, eyebrow_size = 72.0, 34.0, 10.5
    eb_d, eb_w = pf_caps.text_path("VISIT", eyebrow_size, eyebrow_size * 0.34)
    nm_d, nm_w = pf_name.text_path("Moganshan", name_size, name_size * 0.01)
    W = max(mark_size, eb_w, nm_w) + 8
    eb_y = mark_size + 24
    nm_y = eb_y + 10 + name_size * 0.72
    H = nm_y + 8
    body = (f'  <g transform="translate({(W-mark_size)/2:.2f},0) scale({mark_size/96:.5f})">\n'
            + path_el(MARK, BAMBOO, "    ") + '\n  </g>\n'
            f'  <g transform="translate({(W-eb_w)/2:.2f},{eb_y:.2f})"><path fill="{LEAF}" d="{eb_d}"/></g>\n'
            f'  <g transform="translate({(W-nm_w)/2:.2f},{nm_y:.2f})"><path fill="{BAMBOO}" d="{nm_d}"/></g>')
    return svg(round(W, 1), round(H, 1), body)

def build_og():
    eb_d, eb_w = pf_caps.text_path("VISIT", 28.0, 28.0 * 0.34)
    nm_d, nm_w = pf_name.text_path("Moganshan", 92.0, 0.9)
    tg_d, tg_w = pf_caps.text_path("Bamboo, clouds and springs", 25.0, 1.0)
    cx = 600.0
    body = (f'  <rect width="1200" height="630" fill="{BAMBOO}"/>\n'
            f'  <g transform="translate({cx-69:.1f},96) scale(1.44)">\n'
            + path_el(MARK, MIST, "    ") + '\n  </g>\n'
            f'  <g transform="translate({cx-eb_w/2:.1f},348)"><path fill="{AMBER}" d="{eb_d}"/></g>\n'
            f'  <g transform="translate({cx-nm_w/2:.1f},452)"><path fill="{MIST}" d="{nm_d}"/></g>\n'
            f'  <g transform="translate({cx-tg_w/2:.1f},520)">'
            f'<path fill="{MIST}" fill-opacity="0.72" d="{tg_d}"/></g>\n'
            f'  <rect x="0" y="614" width="1200" height="16" fill="{AMBER}"/>')
    return svg(1200, 630, body)

# ---------- emit ----------
print("Writing SVG assets:")
write("mark-primary.svg",      svg(96, 96, path_el(MARK, BAMBOO)))
write("mark-reversed.svg",     svg(96, 96, path_el(MARK, MIST)))
write("mark-currentcolor.svg", svg(96, 96, path_el(MARK, "currentColor")))

duo_cols = [LEAF, BAMBOO, LEAF, BAMBOO, LEAF, BAMBOO, LEAF]
write("mark-duotone.svg", svg(96, 96, "\n".join(
    path_el(d, c) for d, c in zip(culm_paths(), duo_cols))))

write("mark-favicon.svg", svg(96, 96, path_el(FAV, BAMBOO)))
write("app-icon.svg", svg(96, 96,
      f'  <rect width="96" height="96" rx="20" fill="{BAMBOO}"/>\n'
      f'  <g transform="translate(14.4,14.4) scale(0.7)">\n'
      + path_el(FAV, MIST, "    ") + '\n  </g>'))

write("lockup-horizontal.svg",          build_lockup(False))
write("lockup-horizontal-reversed.svg", build_lockup(True))
write("lockup-stacked.svg",             build_stacked())
write("og-image.svg",                   build_og())
print("\nDone.")
