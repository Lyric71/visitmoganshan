#!/usr/bin/env python3
"""Build identity-sheet.html with the current assets inlined."""
import pathlib
A = pathlib.Path("/home/claude/moganshan/assets")

def full(f, style=""):
    return (A / f).read_text().replace("<svg", f"<svg style='{style}'", 1)

BIG = "width:100%;height:auto;max-width:150px"
mark  = full("mark-primary.svg", BIG)
rev   = full("mark-reversed.svg", BIG)
fav   = full("mark-favicon.svg", BIG)
duo   = full("mark-duotone.svg", BIG)
app   = full("app-icon.svg", "width:100%;height:auto;max-width:120px")
lh    = full("lockup-horizontal.svg", "width:100%;height:auto;max-width:400px")
lhr   = full("lockup-horizontal-reversed.svg", "width:100%;height:auto;max-width:400px")
lst   = full("lockup-stacked.svg", "width:100%;height:auto;max-width:230px")
fav16 = full("mark-favicon.svg", "width:16px;height:16px")
fav24 = full("mark-favicon.svg", "width:24px;height:24px")
fav32 = full("mark-favicon.svg", "width:32px;height:32px")
m24   = full("mark-primary.svg", "width:24px;height:24px")
m32   = full("mark-primary.svg", "width:32px;height:32px")
m48   = full("mark-primary.svg", "width:48px;height:48px")

html = f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Visit Moganshan — Identity Sheet</title><style>
:root{{--bamboo:#1F4A3C;--leaf:#3C6B4A;--mist:#E8EDE9;--stone:#D8CFC0;--amber:#E0A458;
--ink:#1A1D1B;--paper:#FBFAF7;--line:#DCD9D2;--muted:#6C6F6B}}
*{{box-sizing:border-box}}
body{{margin:0;background:var(--paper);color:var(--ink);font-size:16px;line-height:1.65;
font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,sans-serif}}
.w{{max-width:1040px;margin:0 auto;padding:0 26px 80px}}
header{{background:var(--bamboo);color:var(--mist);padding:56px 26px 48px}}
header .i{{max-width:1040px;margin:0 auto}}
.eb{{font-size:11px;letter-spacing:.22em;text-transform:uppercase;opacity:.75;margin:0 0 12px}}
h1{{font-family:Georgia,serif;font-weight:400;font-size:36px;margin:0 0 12px}}
header p{{margin:0;max-width:62ch;opacity:.9}}
h2{{font-family:Georgia,serif;font-weight:400;font-size:25px;margin:56px 0 6px;padding-top:24px;
border-top:1px solid var(--line)}}
.sub{{color:var(--muted);margin:0 0 26px;max-width:70ch}}
.grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:16px}}
.card{{border:1px solid var(--line);border-radius:12px;overflow:hidden;background:#fff}}
.box{{display:flex;align-items:center;justify-content:center;padding:26px;min-height:150px;background:var(--mist)}}
.box.dk{{background:var(--bamboo)}} .box.wt{{background:#fff}}
.card p{{margin:0;padding:12px 15px;font-size:12.5px;color:var(--muted);border-top:1px solid var(--line)}}
.card p b{{color:var(--ink);display:block;font-size:13px;margin-bottom:2px}}
.sizes{{display:flex;gap:26px;align-items:flex-end;flex-wrap:wrap;background:#fff;border:1px solid var(--line);
border-radius:12px;padding:22px 24px}}
.sz{{text-align:center}} .sz span{{display:block;font-size:10px;color:var(--muted);margin-top:6px}}
.sw{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));border:1px solid var(--line);
border-radius:12px;overflow:hidden}}
.sw div{{padding:30px 14px 16px;font-size:11px;line-height:1.55}}
.sw b{{display:block;font-size:11.5px;letter-spacing:.04em}}
.sw code{{font-family:ui-monospace,Menlo,monospace;opacity:.85}}
.two{{display:grid;grid-template-columns:1fr 1fr;gap:18px}}
@media(max-width:700px){{.two{{grid-template-columns:1fr}}}}
.do,.dont{{border-radius:12px;padding:20px 24px;font-size:14.5px}}
.do{{background:var(--mist);border-left:4px solid var(--bamboo)}}
.dont{{background:#FBEEEA;border-left:4px solid #A64B36}}
.do h3,.dont h3{{margin:0 0 10px;font-size:14px;letter-spacing:.1em;text-transform:uppercase}}
.do ul,.dont ul{{margin:0;padding-left:18px}} li{{margin-bottom:6px}}
table{{border-collapse:collapse;width:100%;font-size:14.5px}}
th,td{{text-align:left;padding:11px 12px;border-bottom:1px solid var(--line);vertical-align:top}}
th{{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}}
code.k{{font-family:ui-monospace,Menlo,monospace;font-size:12.5px;background:var(--mist);padding:2px 6px;border-radius:4px}}
footer{{color:var(--muted);font-size:13px;border-top:1px solid var(--line);padding-top:20px;margin-top:56px}}
</style></head><body>
<header><div class="i"><p class="eb">Visit Moganshan · Identity Sheet</p>
<h1>Grove / Bamboo &amp; Mist</h1>
<p>Direction 01 in Palette A, wordmark in Playfair Display. Seven uneven bamboo culms tracing a mountain
ridge, with nodes at different heights on every culm — that irregularity is what stops it reading as a chart.
The nodes are knockouts rather than painted bars, so the mark stays correct over photographs.</p></div></header>
<div class="w">

<h2>The mark</h2>
<p class="sub">Vector is the master. Scale the SVG, never the PNG.</p>
<div class="grid">
  <div class="card"><div class="box">{mark}</div><p><b>mark-primary.svg</b>Deep Bamboo. Default, 28px and up.</p></div>
  <div class="card"><div class="box dk">{rev}</div><p><b>mark-reversed.svg</b>Mist, for dark grounds.</p></div>
  <div class="card"><div class="box">{fav}</div><p><b>mark-favicon.svg</b>Reduced, 4 culms. Below 28px only.</p></div>
  <div class="card"><div class="box">{duo}</div><p><b>mark-duotone.svg</b>Optional. Large sizes only.</p></div>
  <div class="card"><div class="box wt">{app}</div><p><b>app-icon.svg</b>Manifest and touch icons.</p></div>
</div>

<h2>Why there are two marks</h2>
<p class="sub">The seven-culm version fills in below roughly 24px. Left is the primary mark, right the reduced
variant at the sizes each is meant for.</p>
<div class="sizes">
  <div class="sz">{m24}<span>primary 24</span></div>
  <div class="sz">{m32}<span>primary 32</span></div>
  <div class="sz">{m48}<span>primary 48</span></div>
  <div style="width:1px;height:48px;background:var(--line)"></div>
  <div class="sz">{fav16}<span>reduced 16</span></div>
  <div class="sz">{fav24}<span>reduced 24</span></div>
  <div class="sz">{fav32}<span>reduced 32</span></div>
</div>

<h2>Lockups</h2>
<p class="sub">Wordmark set in Playfair Display and outlined to paths — no font dependency in the files.</p>
<div class="grid" style="grid-template-columns:repeat(auto-fill,minmax(280px,1fr))">
  <div class="card"><div class="box wt">{lh}</div><p><b>lockup-horizontal.svg</b>Site header. Min width 140px.</p></div>
  <div class="card"><div class="box dk">{lhr}</div><p><b>lockup-horizontal-reversed.svg</b>Dark header, footer, OG.</p></div>
  <div class="card"><div class="box wt">{lst}</div><p><b>lockup-stacked.svg</b>Social profiles, print.</p></div>
</div>

<h2>Palette A — Bamboo &amp; Mist</h2>
<p class="sub">Contrast verified to WCAG 2.1. Ratios are stated so you never have to re-test.</p>
<div class="sw">
  <div style="background:#1F4A3C;color:#E8EDE9"><b>Deep Bamboo</b><code>#1F4A3C</code><br>primary · headings</div>
  <div style="background:#3C6B4A;color:#fff"><b>Leaf</b><code>#3C6B4A</code><br>secondary</div>
  <div style="background:#E8EDE9;color:#1A1D1B"><b>Mist</b><code>#E8EDE9</code><br>background</div>
  <div style="background:#D8CFC0;color:#1A1D1B"><b>Warm Stone</b><code>#D8CFC0</code><br>cards · dividers</div>
  <div style="background:#E0A458;color:#1A1D1B"><b>Sunrise Amber</b><code>#E0A458</code><br>accent · CTA</div>
  <div style="background:#1A1D1B;color:#E8EDE9"><b>Ink</b><code>#1A1D1B</code><br>body text</div>
</div>
<table style="margin-top:18px">
<tr><th>Pairing</th><th>Ratio</th><th>Verdict</th></tr>
<tr><td>Deep Bamboo on Mist</td><td>8.43:1</td><td>AAA — headings, links, any size</td></tr>
<tr><td>Mist on Deep Bamboo</td><td>8.43:1</td><td>AAA — reversed headers and footers</td></tr>
<tr><td>Leaf on Mist</td><td>5.22:1</td><td>AA — fine for body, not for hairline type</td></tr>
<tr><td>Sunrise Amber on Ink</td><td>7.79:1</td><td>AAA — amber button, ink label</td></tr>
<tr><td>Amber text on a light background</td><td>2.1:1</td><td>Fails. Amber is a background colour only.</td></tr>
</table>

<h2>Type</h2>
<table>
<tr><th>Role</th><th>Face</th><th>Notes</th></tr>
<tr><td>Display, headings</td><td><strong>Playfair Display</strong></td><td>Same face as the wordmark. Headings and pull quotes only — never body copy.</td></tr>
<tr><td>Body</td><td><strong>Inter</strong></td><td>17px. Playfair's hairlines thin out at body size; Inter holds up.</td></tr>
<tr><td>Chinese</td><td><strong>Noto Serif SC</strong></td><td>Only where Chinese is genuinely needed.</td></tr>
</table>
<p style="font-size:14px;color:var(--muted)">Both faces are bundled in <code class="k">fonts/</code> as latin woff2
with <code class="k">fonts.css</code> ready to drop in. Self-hosting removes a third-party round trip, which matters
for a site built to earn search traffic.</p>

<h2>Rules</h2>
<div class="two">
<div class="do"><h3>Do</h3><ul>
<li>Leave clear space of one culm width around the mark.</li>
<li>Use <code class="k">mark-favicon.svg</code> below 28px, always.</li>
<li>Use the reversed mark over photographs, on a darkened area.</li>
<li>Use amber as a <em>background</em> with ink text on it.</li>
<li>Ship <code class="k">favicon.ico</code> as well as the SVG — older browsers need it.</li>
</ul></div>
<div class="dont"><h3>Don't</h3><ul>
<li>Don't use the seven-culm mark as the favicon.</li>
<li>Don't set body copy in amber, in leaf below 18px on white, or in Playfair Display at all.</li>
<li>Don't recolour outside the palette, or add gradients or shadows.</li>
<li>Don't stretch the lockup — scale it proportionally.</li>
<li>Don't rebuild the wordmark in another typeface.</li>
</ul></div>
</div>

<h2>Shipping it</h2>
<p class="sub">Copy everything in <code class="k">png/</code> plus <code class="k">favicon.ico</code>,
<code class="k">mark-favicon.svg</code>, <code class="k">site.webmanifest</code> and <code class="k">fonts/</code>
to your site root, then paste <code class="k">head-snippet.html</code> into your <code class="k">&lt;head&gt;</code>.
Import <code class="k">tokens.css</code> and <code class="k">fonts.css</code>.</p>

<footer>Visit Moganshan · Direction 01 Grove, Palette A · built 4 August 2026.
Contrast computed to WCAG 2.1 relative luminance. Wordmark outlined from Playfair Display (SIL Open Font License).</footer>
</div></body></html>"""

pathlib.Path("/home/claude/moganshan/identity-sheet.html").write_text(html)
print("identity-sheet.html", len(html), "bytes")
