#!/usr/bin/env python3
"""Rasterise the SVG set to PNG/ICO at the sizes a website actually needs."""
import pathlib, base64
from playwright.sync_api import sync_playwright
from PIL import Image

A = pathlib.Path("/home/claude/moganshan/assets")
P = A / "png"
P.mkdir(exist_ok=True)

# (source svg, output name, width, height, transparent?)
JOBS = [
    ("mark-favicon.svg", "favicon-16.png",         16,  16,  True),
    ("mark-favicon.svg", "favicon-32.png",         32,  32,  True),
    ("mark-favicon.svg", "favicon-48.png",         48,  48,  True),
    ("app-icon.svg",     "apple-touch-icon.png",  180, 180,  False),
    ("app-icon.svg",     "icon-192.png",          192, 192,  False),
    ("app-icon.svg",     "icon-512.png",          512, 512,  False),
    ("mark-primary.svg", "mark-512.png",          512, 512,  True),
    ("mark-primary.svg", "mark-1024.png",        1024, 1024, True),
    ("mark-reversed.svg","mark-reversed-512.png", 512, 512,  True),
    ("lockup-horizontal.svg",          "lockup-horizontal-1600.png",         1600, 0, True),
    ("lockup-horizontal-reversed.svg", "lockup-horizontal-reversed-1600.png",1600, 0, True),
    ("lockup-stacked.svg",             "lockup-stacked-1200.png",            1200, 0, True),
    ("og-image.svg",     "og-image.png",         1200, 630, False),
]

def svg_dims(text):
    import re
    m = re.search(r'viewBox="([\d.\- ]+)"', text)
    _, _, w, h = [float(v) for v in m.group(1).split()]
    return w, h

with sync_playwright() as pw:
    b = pw.chromium.launch(args=["--force-color-profile=srgb"])
    for src, out, w, h, transparent in JOBS:
        svg = (A / src).read_text()
        vw, vh = svg_dims(svg)
        if h == 0:
            h = round(w * vh / vw)
        pg = b.new_page(viewport={"width": w, "height": h}, device_scale_factor=1)
        bg = "transparent" if transparent else "#1F4A3C"
        inject = "<svg preserveAspectRatio='xMidYMid meet' style='width:100%;height:100%;display:block'"
        svg_fit = svg.replace("<svg", inject, 1)
        pg.set_content(
            '<html><body style="margin:0;background:' + bg + '">'
            + '<div style="width:' + str(w) + 'px;height:' + str(h) + 'px">'
            + svg_fit + '</div></body></html>')
        pg.wait_for_timeout(120)
        pg.screenshot(path=str(P / out), omit_background=transparent)
        pg.close()
        print(f"   {out:42s} {w}x{h}")
    b.close()

# multi-resolution favicon.ico
ico_srcs = [Image.open(P / f"favicon-{s}.png").convert("RGBA") for s in (16, 32, 48)]
ico_srcs[2].save(A / "favicon.ico", format="ICO",
                 sizes=[(16, 16), (32, 32), (48, 48)])
print("   favicon.ico                                16/32/48")
